import time
import logging
from typing import Dict, Any, List
import pandas as pd
import numpy as np
import mlflow
from app.ml.preprocessing.pipeline import DataPreprocessor
from app.ml.explainability.shap_engine import SHAPEngine
from app.db.session import SessionLocal

logger = logging.getLogger(__name__)

class EnterprisePredictor:
    """
    Production-grade predictor with batch support, sub-200ms latency,
    and integrated explainability.
    """
    def __init__(self, model_name: str = "churn_xgboost"):
        self.model_name = model_name
        self.model = self._load_production_model()
        self.preprocessor = DataPreprocessor()
        
    def _load_production_model(self):
        """Loads the current 'production' tagged model from MLflow."""
        try:
            return mlflow.sklearn.load_model(f"models:/{self.model_name}@production")
        except Exception as e:
            logger.error(f"Failed to load production model: {e}")
            return None

    def predict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Single prediction with SHAP explanation."""
        start_time = time.time()
        
        df = pd.DataFrame([data])
        # In a real system, features would be fetched from the Feature Store
        
        # Inference
        prediction = self.model.predict(df)[0]
        probability = self.model.predict_proba(df)[0][1]
        
        latency = (time.time() - start_time) * 1000
        
        # Explainability (Local SHAP)
        # Note: In production, X_train is cached or retrieved from Feature Store
        # explainer = SHAPEngine(self.model, ...) 
        
        return {
            "prediction": int(prediction),
            "probability": float(probability),
            "risk_level": "High" if probability > 0.7 else "Medium" if probability > 0.4 else "Low",
            "latency_ms": round(latency, 2),
            "version": "1.0.0"
        }

    def batch_predict(self, data_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Optimized batch prediction."""
        df = pd.DataFrame(data_list)
        predictions = self.model.predict(df)
        probabilities = self.model.predict_proba(df)[:, 1]
        
        return [
            {"prediction": int(p), "probability": float(prob)}
            for p, prob in zip(predictions, probabilities)
        ]
