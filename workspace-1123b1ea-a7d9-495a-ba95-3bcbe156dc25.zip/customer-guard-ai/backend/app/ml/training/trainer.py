import logging
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split
import optuna
import mlflow
import mlflow.sklearn
import shap
import xgboost as xgb
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

logger = logging.getLogger(__name__)

class DataPreprocessor:
    """Handles automatic schema detection, missing values, and encoding."""
    def __init__(self):
        self.pipeline = None

    def build_pipeline(self, X: pd.DataFrame):
        numeric_features = X.select_dtypes(include=['int64', 'float64']).columns
        categorical_features = X.select_dtypes(include=['object', 'category']).columns

        numeric_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])

        categorical_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
            ('onehot', OneHotEncoder(handle_unknown='ignore'))
        ])

        self.pipeline = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, numeric_features),
                ('cat', categorical_transformer, categorical_features)
            ])
        return self.pipeline

class ChurnTrainer:
    """Enterprise-grade training engine with Optuna tuning and MLflow tracking."""
    def __init__(self, model_name: str = "churn_xgboost"):
        self.model_name = model_name
        self.preprocessor = DataPreprocessor()
        self.best_model = None

    def objective(self, trial, X_train, y_train, X_val, y_val):
        params = {
            'n_estimators': trial.suggest_int('n_estimators', 100, 1000),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
            'subsample': trial.suggest_float('subsample', 0.5, 1.0),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0)
        }
        
        model = xgb.XGBClassifier(**params, use_label_encoder=False, eval_metric='logloss')
        model.fit(X_train, y_train)
        preds = model.predict(X_val)
        return f1_score(y_val, preds)

    def train(self, X: pd.DataFrame, y: pd.Series):
        mlflow.set_experiment(self.model_name)
        with mlflow.start_run():
            X_processed = self.preprocessor.build_pipeline(X).fit_transform(X)
            X_train, X_val, y_train, y_val = train_test_split(X_processed, y, test_size=0.2)

            study = optuna.create_study(direction='maximize')
            study.optimize(lambda trial: self.objective(trial, X_train, y_train, X_val, y_val), n_trials=20)
            
            best_params = study.best_params
            self.best_model = xgb.XGBClassifier(**best_params)
            self.best_model.fit(X_train, y_train)
            
            # Log to MLflow
            mlflow.log_params(best_params)
            mlflow.sklearn.log_model(self.best_model, "model")
            
            logger.info(f"Training complete. Best F1: {study.best_value}")
            return self.best_model
