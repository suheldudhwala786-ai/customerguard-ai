# CustomerGuard AI

Enterprise AI platform for predicting customer churn with explainability.

## 🚀 Key Features
- **Predictive Engine**: High-accuracy XGBoost/CatBoost churn models.
- **SHAP Explainability**: Understand *why* customers churn with visual feature impact analysis.
- **Enterprise SaaS UI**: Built with Next.js 15, Tailwind, and ShadCN.
- **Automated Pipeline**: End-to-end ML training, registry, and drift detection.
- **Production Ready**: JWT Auth, RBAC, PostgreSQL, Redis, Dockerized.

## 🏗️ Architecture
- **Frontend**: Next.js 15 + Tailwind CSS v4
- **Backend**: FastAPI + SQLAlchemy + Alembic
- **MLOps**: MLflow + Optuna + SHAP

## 🛠️ Quick Start

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## 📜 License
MIT
