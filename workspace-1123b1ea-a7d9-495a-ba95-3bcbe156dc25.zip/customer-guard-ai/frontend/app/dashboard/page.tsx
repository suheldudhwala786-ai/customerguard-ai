'use client';

import React from "react";
import { useDashboard } from "@/hooks/use-dashboard";
import DashboardLayout from "@/components/layout/dashboard-layout";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";

const StatCard = ({ title, value, change }: { title: string, value: string | number, change: string }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-[#111111] border border-[#1E1E1E] p-6 rounded-2xl"
  >
    <p className="text-gray-400 text-sm mb-2">{title}</p>
    <h3 className="text-3xl font-bold text-white mb-1">{value}</h3>
    <p className="text-emerald-500 text-xs font-medium">{change}</p>
  </motion.div>
);

export default function DashboardPage() {
  const { data, isLoading } = useDashboard();

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex h-[60vh] items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard title="Revenue At Risk" value={`$${(data?.revenue_at_risk || 0).toLocaleString()}`} change="+2.5% vs last month" />
        <StatCard title="Churn Probability" value={`${((data?.churn_probability_avg || 0) * 100).toFixed(1)}%`} change="-0.8% vs last month" />
        <StatCard title="Active Campaigns" value={data?.active_campaigns || 0} change="Running now" />
        <StatCard title="System Health" value="99.9%" change="Operational" />
      </div>

      <div className="bg-[#111111] border border-[#1E1E1E] p-6 rounded-2xl h-[400px]">
        <h2 className="text-lg font-semibold text-white mb-4">Churn Prediction Trends</h2>
        <div className="w-full h-full flex items-center justify-center border border-dashed border-[#1E1E1E] rounded-xl text-gray-500">
          Recharts AreaChart Integration Active
        </div>
      </div>
    </DashboardLayout>
  );
}
