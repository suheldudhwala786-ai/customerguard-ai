import React, { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, AlertTriangle, TrendingDown, RefreshCw } from "lucide-react";
import DashboardLayout from "@/components/layout/dashboard-layout";
import { Card } from "@/components/ui/primitives";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

// Mock SHAP data structure representing backend explanation response
const mockShapData = [
  { feature: "Support Tickets", impact: 0.45 },
  { feature: "Usage Frequency", impact: -0.35 },
  { feature: "Payment Failures", impact: 0.25 },
  { feature: "Tenure", impact: -0.15 },
  { feature: "Monthly Spend", impact: 0.10 },
];

export default function PredictionPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handlePredict = async () => {
    setLoading(true);
    // Simulate API call to backend/api/v1/predictions
    await new Promise(resolve => setTimeout(resolve, 800));
    setResult({
      probability: 0.82,
      risk: "High",
      recommendation: "20% Retention Discount + Priority Support"
    });
    setLoading(false);
  };

  return (
    <DashboardLayout>
      <div className="max-w-5xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-white">Churn Predictor</h1>
          <p className="text-gray-400 mt-2">Run high-fidelity inference with SHAP explainability.</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-1 h-fit">
            <h2 className="text-lg font-semibold text-white mb-4">Input Parameters</h2>
            <div className="space-y-4">
              <input type="text" placeholder="Customer ID" className="w-full bg-[#0A0A0A] border border-[#1E1E1E] rounded-lg p-3 text-white" />
              <button 
                onClick={handlePredict}
                className="w-full bg-indigo-600 py-3 rounded-lg font-medium hover:bg-indigo-700 transition"
              >
                {loading ? <Loader2 className="animate-spin mx-auto" /> : "Run Inference"}
              </button>
            </div>
          </Card>

          {result && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="lg:col-span-2 space-y-6"
            >
              <Card>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-gray-400 text-sm">Churn Probability</h3>
                    <p className="text-4xl font-bold text-rose-500">{(result.probability * 100).toFixed(1)}%</p>
                  </div>
                  <span className="px-3 py-1 bg-rose-500/10 text-rose-500 rounded-full text-xs font-bold border border-rose-500/20">
                    {result.risk} RISK
                  </span>
                </div>
              </Card>

              <Card>
                <h3 className="text-lg font-semibold text-white mb-6">SHAP Feature Impact</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={mockShapData} layout="vertical">
                      <XAxis type="number" />
                      <YAxis dataKey="feature" type="category" width={100} />
                      <Tooltip contentStyle={{ backgroundColor: '#111111', borderColor: '#1E1E1E' }} />
                      <Bar dataKey="impact">
                        {mockShapData.map((entry, index) => (
                          <Cell key={index} fill={entry.impact > 0 ? '#f43f5e' : '#10b981'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
