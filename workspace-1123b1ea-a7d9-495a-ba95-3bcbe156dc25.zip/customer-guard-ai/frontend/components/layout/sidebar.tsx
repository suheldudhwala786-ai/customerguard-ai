import React from "react";
import Link from "next/link";
import { LayoutDashboard, Users, BrainCircuit, BarChart3, Settings, LogOut, Search, Bell } from "lucide-react";
import { motion } from "framer-motion";

const sidebarLinks = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Customers", href: "/customers", icon: Users },
  { name: "Predictions", href: "/predictions", icon: BrainCircuit },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 border-r border-[#1E1E1E] bg-[#0A0A0A] p-4 flex flex-col">
      <div className="flex items-center gap-2 px-2 py-4 mb-8">
        <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
          <BrainCircuit className="text-white w-5 h-5" />
        </div>
        <span className="font-bold text-white tracking-tight">CustomerGuard</span>
      </div>

      <nav className="flex-1 space-y-1">
        {sidebarLinks.map((link) => (
          <Link
            key={link.name}
            href={link.href}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-gray-400 hover:bg-[#111111] hover:text-white transition-all"
          >
            <link.icon className="w-5 h-5" />
            {link.name}
          </Link>
        ))}
      </nav>

      <div className="pt-4 border-t border-[#1E1E1E]">
        <button className="flex items-center gap-3 px-3 py-2 text-gray-400 hover:text-rose-400 transition-colors">
          <LogOut className="w-5 h-5" />
          Logout
        </button>
      </div>
    </aside>
  );
}
