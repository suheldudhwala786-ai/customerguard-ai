import React from "react";
import Sidebar from "@/components/layout/sidebar";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-[#0A0A0A] text-gray-100">
      <Sidebar />
      <main className="flex-1 ml-64 p-8">
        <header className="flex items-center justify-between mb-8 pb-4 border-b border-[#1E1E1E]">
          <h1 className="text-2xl font-bold tracking-tight">Executive Dashboard</h1>
          <div className="flex items-center gap-4">
            <div className="bg-[#111111] border border-[#1E1E1E] rounded-full px-4 py-1.5 text-sm text-gray-400">
              Org: Acme Corp
            </div>
            <div className="w-8 h-8 rounded-full bg-indigo-600"></div>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}
